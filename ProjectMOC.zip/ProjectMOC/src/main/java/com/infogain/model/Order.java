package com.infogain.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalIdCache;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
@Entity
@Table(name = "ORDERNEW1")
@EntityListeners({ AuditingEntityListener.class })
@NaturalIdCache
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	int orderId;
	@ManyToMany()
    @JoinColumn(name = "orderId", referencedColumnName = "itemId")
	List<Item> item;

	public int getOrderId() {
		return orderId;
	}


	public Order(int orderId, List<Item> item) {
		super();
		this.orderId = orderId;
		this.item = item;
	}


	public List<Item> getItem() {
		return item;
	}


	public void setItem(List<Item> item) {
		this.item = item;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public Order() {
		// TODO Auto-generated constructor stub
	}

}
