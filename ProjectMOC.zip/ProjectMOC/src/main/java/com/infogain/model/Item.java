package com.infogain.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "Items")
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int itemId;
	String itemName;
	int itemPrepTime;
	int itemPrice;
	@ManyToMany(mappedBy = "item", fetch = FetchType.LAZY)
	@NotFound(action = NotFoundAction.IGNORE)
	List<Order> order;

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public Item(int itemId, String itemName, int itemPrepTime, int itemPrice) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrepTime = itemPrepTime;
		this.itemPrice = itemPrice;
	}

	@Column
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	@Column
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Column
	public int getItemPrepTime() {
		return itemPrepTime;
	}

	public void setItemPrepTime(int itemPrepTime) {
		this.itemPrepTime = itemPrepTime;
	}

	public Item() {
		// TODO Auto-generated constructor stub
	}

}
