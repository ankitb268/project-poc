package com.infogain.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infogain.model.Order;
import com.infogain.service.OrderRepository;

@RestController
@RequestMapping("/order")
public class OrderController {
	@Autowired
	OrderRepository orderService;

	@GetMapping(value = "Orders")
	public List<Order> showAll() {
		return orderService.findAll();
	}

	@GetMapping(value = "findItem/{orderId}")
	public Order findOrder(@PathVariable(value = "orderId") int orderId) {
		return orderService.findOne(orderId);

	}

	@PostMapping(value = "addOrder")
	public String addOrder(@Valid @RequestBody Order order) {
		return orderService.save(order);
	}

	  
	  @DeleteMapping(value = "deleteOrder/{orderId}") public String
	  deleteItem(@PathVariable(value = "orderId") int id) { return
	  orderService.delete(id);
	 
	}

	@DeleteMapping(value = "delete")
	public String deleteAll() {
		return orderService.deleteAll();
	}

}
