package com.infogain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectMocApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectMocApplication.class, args);
		System.out.println("hello");
	}

}
